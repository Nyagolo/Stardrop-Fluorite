using Stardrop.Models.Data.Enums;
using Stardrop.Models.Nexus;
using Stardrop.Models.SMAPI;

namespace Stardrop.Models
{
    public class Settings
    {
        public string Theme { get; set; } = "Stardrop";
        public string Language { get; set; }
        public ModGrouping ModGroupingMethod { get; set; } = ModGrouping.None;
        public string Version { get; set; }
        public string LastSelectedProfileName { get; set; }
        public string SMAPIFolderPath { get; set; }
        public string ModFolderPath { get; set; }
        public string ModInstallPath { get; set; }
        /// <summary>
        /// Where a collection installs the mods it pins. Kept outside the mod folder, as a collection installs its
        /// own copy of every mod and SMAPI skips every copy of a duplicated unique ID rather than picking one. An
        /// empty value falls back to <see cref="Utilities.Pathing.GetDefaultCollectionsFolderPath"/>. Only the mods
        /// follow this: the collection records stay alongside the profiles under the data folder, as they are small
        /// and are keyed by source ID rather than by path.
        /// </summary>
        public string CollectionInstallPath { get; set; }
        public bool IgnoreHiddenFolders { get; set; } = true;
        public bool EnableProfileSpecificModConfigs { get; set; }
        public bool ShouldWriteToModConfigs { get; set; }
        public bool EnableModsOnAdd { get; set; }
        /// <summary>
        /// Whether to always ask before deleting a previous version of a mod when updating the mod.
        /// </summary>
        public bool AlwaysAskToDelete { get; set; } = true;
        public bool ShouldAutomaticallySaveProfileChanges { get; set; } = true;
        public bool ShowModThumbnails { get; set; }
        /// <summary>
        /// Edge length of the mod thumbnail in the grid, in pixels. Shrinking it makes rows shorter and fits
        /// more mods on screen; 125 is the size the grid used before this was configurable.
        /// </summary>
        public int ModThumbnailSize { get; set; } = 125;
        public NexusServers PreferredNexusServer { get; set; } = NexusServers.NexusCDN;
        public bool IsAskingBeforeAcceptingNXM { get; set; } = true;
        /// <summary>
        /// Whether adding a mod while a collection profile is active asks where it should go. When this is off the
        /// mod is installed into that collection's folder without asking.
        /// </summary>
        public bool AlwaysAskForCollectionInstallTarget { get; set; } = true;
        /// <summary>Whether a collection entry's link asks Nexus Mods for the mod manager download rather than the plain file page</summary>
        public bool UseNXMLinks { get; set; } = true;
        /// <summary>
        /// Whether SMAPI is told to leave a collection's mods out of its own update checks. Stardrop already keeps
        /// them out of its, since the collection owns their versions, and without this SMAPI's console reports
        /// updates the user is not meant to act on.
        /// </summary>
        public bool CollectionsSkipSMAPIUpdateCheck { get; set; } = true;
        public GameDetails GameDetails { get; set; }
        public NexusUser NexusDetails { get; set; }

        public Settings ShallowCopy()
        {
            return (Settings)this.MemberwiseClone();
        }
    }
}
