using Avalonia.Collections;
using Avalonia.Controls;
using Avalonia.Threading;
using Json.More;
using ReactiveUI;
using SharpCompress.Archives;
using SharpCompress.Common;
using Stardrop.Models;
using Stardrop.Models.Data;
using Stardrop.Models.Data.Enums;
using Stardrop.Models.SMAPI;
using Stardrop.Utilities;
using Stardrop.Utilities.Extension;
using Stardrop.Utilities.External;
using Stardrop.Utilities.Internal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Stardrop.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        private string ChromeHint { get; set; } = "NoChrome";
        private bool HasSystemDecorations { get; set; } = true;
        private bool ShowTitle { get; set; } = true;
        private bool ShowMainMenu { get; set; } = true;
        private bool ShowWindowMenu { get; set; } = true;

        private DataGridPathGroupDescription _modPathGrouping = new DataGridPathGroupDescription(nameof(Mod.Path));
        private DataGridPathGroupDescription _rootPathGrouping = new DataGridPathGroupDescription(nameof(Mod.RootPath));
        private DataGridPathGroupDescription _frameworkGrouping = new DataGridPathGroupDescription(nameof(Mod.FrameworkID));
        private DataGridPathGroupDescription _customCategoryRootGrouping = new DataGridPathGroupDescription(nameof(Mod.CustomCategoryRoot));
        private readonly DataGridPathGroupDescription _customCategorySubGrouping = GroupDirectModsFirst(nameof(Mod.CustomCategorySub));
        private readonly DataGridPathGroupDescription _customCategoryThirdGrouping = GroupDirectModsFirst(nameof(Mod.CustomCategoryThird));

        private string _dragOverColor = "#ff9f2a";
        public string DragOverColor { get { return _dragOverColor; } set { this.RaiseAndSetIfChanged(ref _dragOverColor, value); } }
        private bool _isLocked;
        public bool IsLocked { get { return _isLocked; } set { this.RaiseAndSetIfChanged(ref _isLocked, value); } }
        private bool _isCheckingForUpdates;
        public bool IsCheckingForUpdates { get { return _isCheckingForUpdates; } set { this.RaiseAndSetIfChanged(ref _isCheckingForUpdates, value); } }
        private readonly ModList _mods = new ModList();
        public ObservableCollection<Mod> Mods => _mods;

        private sealed class ModList : ObservableCollection<Mod>
        {
            internal void ReplaceAll(List<Mod> mods)
            {
                Items.Clear();
                foreach (var mod in mods)
                {
                    Items.Add(mod);
                }
                OnPropertyChanged(new PropertyChangedEventArgs(nameof(Count)));
                OnPropertyChanged(new PropertyChangedEventArgs("Item[]"));
                OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
            }
        }
        private int _enabledModCount;
        public int EnabledModCount { get { return _enabledModCount; } set { this.RaiseAndSetIfChanged(ref _enabledModCount, value); } }
        private int _actualModCount;
        public int ActualModCount { get { return _actualModCount; } set { this.RaiseAndSetIfChanged(ref _actualModCount, value); } }
        public DataGridCollectionView DataView { get; set; }

        private DisplayFilter _disabledModFilter;
        public DisplayFilter DisabledModFilter { get { return _disabledModFilter; } set { _disabledModFilter = value; UpdateFilter(); } }

        private bool _showUpdatableMods;
        // Refreshes the counts as well as the grid, as this now widens the source scope both of them read
        public bool ShowUpdatableMods { get { return _showUpdatableMods; } set { _showUpdatableMods = value; UpdateFilter(); RefreshModCounts(); } }
        private ModSourceFilter _modSourceFilter = ModSourceFilter.ActiveProfile;
        public ModSourceFilter ModSourceFilter { get { return _modSourceFilter; } set { _modSourceFilter = value; UpdateFilter(); RefreshModCounts(); } }
        private bool _hasCollectionMods;
        /// <summary>Whether any installed mod belongs to a collection. Drives the visibility of the source filter, which is noise for users with no collections</summary>
        public bool HasCollectionMods { get { return _hasCollectionMods; } set { this.RaiseAndSetIfChanged(ref _hasCollectionMods, value); } }
        private Profile? _activeProfile;
        private HashSet<ModReference> _activeProfileReferences = new HashSet<ModReference>();
        private bool _showEndorsements;
        public bool ShowEndorsements { get { return _showEndorsements; } set { this.RaiseAndSetIfChanged(ref _showEndorsements, value); } }
        private bool _showInstalls;
        public bool ShowInstalls { get { return _showInstalls; } set { this.RaiseAndSetIfChanged(ref _showInstalls, value); } }
        private bool _isNexusConnected;
        /// <summary>Visibility preferences from the column context menu, keyed by ext:ColumnExtensions.Key</summary>
        private Dictionary<string, bool> _columnPreferences = new Dictionary<string, bool>();
        private string _filterText;
        public string FilterText { get { return _filterText; } set { _filterText = value; UpdateFilter(); } }
        private List<string> _columnFilter;
        public List<string> ColumnFilter { get { return _columnFilter; } set { _columnFilter = value; UpdateFilter(); } }
        private string _updateStatusText = Program.translation.Get("ui.main_window.button.update_status.generic");
        public string UpdateStatusText { get { return _updateStatusText; } set { this.RaiseAndSetIfChanged(ref _updateStatusText, value); } }
        private string _downloadsButtonText;
        public string DownloadsButtonText { get => _downloadsButtonText; set => this.RaiseAndSetIfChanged(ref _downloadsButtonText, value); }
        private int _modsWithCachedUpdates;
        public int ModsWithCachedUpdates { get { return _modsWithCachedUpdates; } set { this.RaiseAndSetIfChanged(ref _modsWithCachedUpdates, value); } }
        private int _collectionsWithUpdates;
        /// <summary>
        /// Collections sitting behind a newer revision. Shown beside the mod update count as a pointer towards the
        /// collections window, which is where the update itself is described and acted on.
        /// </summary>
        public int CollectionsWithUpdates
        {
            get { return _collectionsWithUpdates; }
            set
            {
                this.RaiseAndSetIfChanged(ref _collectionsWithUpdates, value);
                this.RaisePropertyChanged(nameof(HasCollectionUpdates));
            }
        }
        /// <summary>Hides the collection update count outright, rather than showing a zero to the many users who have no collections</summary>
        public bool HasCollectionUpdates { get { return _collectionsWithUpdates > 0; } }
        public string Version { get; set; }

        private string _nexusStatus = String.Concat("Nexus Mods: ", Program.translation.Get("internal.disconnected"));
        public string NexusStatus { get { return _nexusStatus; } set { this.RaiseAndSetIfChanged(ref _nexusStatus, String.Concat("Nexus Mods: ", value)); } }

        private string _nexusLimits;
        public string NexusLimits { get { return _nexusLimits; } set { this.RaiseAndSetIfChanged(ref _nexusLimits, value); } }
        private string _smapiVersion;
        public string SmapiVersion { get { return String.IsNullOrEmpty(_smapiVersion) ? Program.translation.Get("ui.main_window.labels.unknown_SMAPI") : $"v{_smapiVersion}"; } set { this.RaiseAndSetIfChanged(ref _smapiVersion, value); } }

        public bool ShowSaveProfileChanges { get { return _showSaveProfileChanges; } set { this.RaiseAndSetIfChanged(ref _showSaveProfileChanges, value); } }
        private bool _showSaveProfileChanges;
        public bool AreModGroupsEnabled { get { return _areModGroupsEnabled; } set { this.RaiseAndSetIfChanged(ref _areModGroupsEnabled, value); } }
        private bool _areModGroupsEnabled = Program.settings.ModGroupingMethod != ModGrouping.None;
        public bool ShowModThumbnails { get { return _showModThumbnails; } set { this.RaiseAndSetIfChanged(ref _showModThumbnails, value); } }
        /// <summary>
        /// Edge length of the thumbnails in the grid. Kept on the view model so changing it in settings can
        /// resize the rows without reloading the mod list.
        /// </summary>
        public double ModThumbnailSize { get { return _modThumbnailSize; } set { this.RaiseAndSetIfChanged(ref _modThumbnailSize, value); } }
        private double _modThumbnailSize = Program.settings.ModThumbnailSize;
        private bool _showModThumbnails = Program.settings.ShowModThumbnails;
        public string ModGroupsStateButtonText { get { return _modGroupsStateButtonText; } set { this.RaiseAndSetIfChanged(ref _modGroupsStateButtonText, value); } }
        private string _modGroupsStateButtonText = Program.settings.ModGroupingMethod != ModGrouping.None ? Program.translation.Get("ui.main_window.buttons.mod_groups_state.collapse") : Program.translation.Get("ui.main_window.buttons.mod_groups_state.expand");

        public MainWindowViewModel(string modsFilePath, string version)
        {
            DiscoverMods(modsFilePath);
            Version = $"v{version}";
            SmapiVersion = Program.settings.GameDetails?.SmapiVersion;

            // Create data view
            DataView = new DataGridCollectionView(Mods, isDataSorted: false, isDataInGroupOrder: false);
            DataView.SortDescriptions.CollectionChanged += DataViewSortDescription_CollectionChanged;

            UpdateFilter();

            DataView.SortDescriptions.Add(DataGridSortDescription.FromPath(nameof(Mod.Name), ListSortDirection.Ascending));

            // Do OS specific setup
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                ChromeHint = "Default";
                ShowMainMenu = false;
                ShowWindowMenu = false;
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                ChromeHint = "Default";
                ShowWindowMenu = false;
                ShowTitle = false;
            }
        }

        public void OpenBrowser(string url)
        {
            Toolkit.OpenBrowser(url);
        }

        public void ChangeColumnVisibility(MenuItem column)
        {
            if (column is null)
            {
                return;
            }

            var modGrid = column.FindControl<DataGrid>("modGrid");
            if (modGrid is null)
            {
                return;
            }

            if (column.Classes.Contains("ColumnInactive"))
            {
                SetColumnVisibility(column, modGrid, true);
            }
            else
            {
                SetColumnVisibility(column, modGrid, false);
            }
        }

        public void SetColumnVisibility(MenuItem column, DataGrid modGrid, bool isActive)
        {
            if (column.Header is not string header)
            {
                return;
            }

            var targetColumn = modGrid.Columns.FirstOrDefault(c => c.Header is string text && text == header);
            if (targetColumn is null)
            {
                return;
            }

            // Get the local data
            ClientData localDataCache = new ClientData();
            if (File.Exists(Pathing.GetDataCachePath()))
            {
                localDataCache = JsonSerializer.Deserialize<ClientData>(File.ReadAllText(Pathing.GetDataCachePath()), new JsonSerializerOptions { AllowTrailingCommas = true });
            }

            if (isActive)
            {
                column.Classes.Remove("ColumnInactive");
                column.Classes.Add("ColumnActive");
            }
            else
            {
                column.Classes.Remove("ColumnActive");
                column.Classes.Add("ColumnInactive");
            }

            ApplyColumnVisibility(targetColumn, isActive);
            localDataCache.ColumnActiveStates[header] = isActive;

            // Cache the local data
            File.WriteAllText(Pathing.GetDataCachePath(), JsonSerializer.Serialize(localDataCache, new JsonSerializerOptions() { WriteIndented = true }));
        }

        /// <summary>
        /// Stores the user's choice for a column, then shows it only if its gate also allows it. Gated columns
        /// stay hidden until the gate opens, at which point RefreshGatedColumns applies the stored choice.
        /// </summary>
        private void ApplyColumnVisibility(DataGridColumn targetColumn, bool isActive)
        {
            var columnKey = ColumnExtensions.GetKey(targetColumn);
            if (String.IsNullOrEmpty(columnKey) is false)
            {
                _columnPreferences[columnKey] = isActive;
            }

            targetColumn.IsVisible = isActive && IsColumnGateOpen(targetColumn);
        }

        /// <summary>Whether anything outside the user's own preference is currently blocking a column</summary>
        private bool IsColumnGateOpen(DataGridColumn targetColumn)
        {
            if (ColumnExtensions.GetRequiresNexus(targetColumn) is false)
            {
                return true;
            }

            return _isNexusConnected;
        }

        /// <summary>
        /// Reapplies stored preferences for every column gated on Nexus, called when that connection is made or
        /// lost. Columns with no stored preference default to visible, as the gate is what was hiding them.
        /// </summary>
        public void RefreshGatedColumns(DataGrid modGrid, bool isNexusConnected)
        {
            _isNexusConnected = isNexusConnected;

            foreach (var targetColumn in modGrid.Columns)
            {
                if (ColumnExtensions.GetRequiresNexus(targetColumn) is false)
                {
                    continue;
                }

                var columnKey = ColumnExtensions.GetKey(targetColumn);
                if (String.IsNullOrEmpty(columnKey))
                {
                    Program.helper.Log($"Failed to gate column {targetColumn.Header}: it lacks an ext:ColumnExtensions.Key value in the XAML.");
                    continue;
                }

                bool isEnabled = _columnPreferences.TryGetValue(columnKey, out bool preference) ? preference : true;
                targetColumn.IsVisible = isEnabled && isNexusConnected;
            }
        }

        public void SetColumnOrder(DataGrid modGrid)
        {
            // Get the local data
            ClientData localDataCache = new ClientData();
            if (File.Exists(Pathing.GetDataCachePath()))
            {
                localDataCache = JsonSerializer.Deserialize<ClientData>(File.ReadAllText(Pathing.GetDataCachePath()), new JsonSerializerOptions { AllowTrailingCommas = true });
            }

            if (localDataCache is not null && modGrid is not null && modGrid.Columns is not null)
            {
                localDataCache.ColumnOrder.Clear();
                foreach (var column in modGrid.Columns)
                {
                    var columnKey = ColumnExtensions.GetKey(column);
                    if (string.IsNullOrEmpty(columnKey))
                    {
                        Program.helper.Log($"Failed to reorder column {column.Header.ToString()}: it lacks an ext:ColumnExtensions.Key value in the XAML.");
                        continue;
                    }
                    localDataCache.ColumnOrder[columnKey] = column.DisplayIndex;
                }

                // Cache the local data
                File.WriteAllText(Pathing.GetDataCachePath(), JsonSerializer.Serialize(localDataCache, new JsonSerializerOptions() { WriteIndented = true }));
            }
        }

        public bool ParentFolderContainsPeriod(string oldestAncestorPath, DirectoryInfo? directoryInfo)
        {
            if (directoryInfo is null)
            {
                return false;
            }
            else if (directoryInfo.Name[0] == '.')
            {
                return true;
            }

            var ancestorFolder = directoryInfo.Parent;
            while (ancestorFolder is not null && !ancestorFolder.FullName.Equals(oldestAncestorPath, StringComparison.OrdinalIgnoreCase))
            {
                if (ancestorFolder.Name[0] == '.')
                {
                    return true;
                }

                ancestorFolder = ancestorFolder.Parent;
            }

            return false;
        }

        /// <summary>
        /// Every installed collection's record, keyed by the source ID its mods carry. Read once per pass, as the
        /// cache goes to disk on every call and every mod in a collection resolves to the same record.
        /// </summary>
        private static Dictionary<string, CollectionInstall> GetCollectionsBySourceId()
        {
            var collectionsBySourceId = new Dictionary<string, CollectionInstall>(StringComparer.OrdinalIgnoreCase);
            foreach (var collection in CollectionCache.LoadAll())
            {
                collectionsBySourceId[collection.SourceId] = collection;
            }

            return collectionsBySourceId;
        }

        /// <summary>
        /// Fills in what a collection mod shows about the collection it belongs to. Name can be empty on a record
        /// built from a collection that never reported one, so the slug stands in for it, which is the same
        /// fallback GetAvailableProfileName uses when naming the generated profile.
        ///
        /// A copy the record does not pin is one the user added into the collection's folder. Where the record
        /// itself is missing nothing is marked, since a collection whose record has been lost pins nothing at all
        /// and would otherwise report every mod it installed as an addition of the user's.
        /// </summary>
        private static void ApplyCollectionDetails(Mod mod, Dictionary<string, CollectionInstall> collectionsBySourceId)
        {
            if (String.IsNullOrEmpty(mod.SourceId))
            {
                return;
            }

            if (collectionsBySourceId.TryGetValue(mod.SourceId, out var collection) is false)
            {
                mod.CollectionName = mod.SourceId;
                mod.IsCollectionAddOn = false;
                return;
            }

            mod.CollectionName = String.IsNullOrEmpty(collection.Name) ? collection.Slug : collection.Name;
            mod.IsCollectionAddOn = collection.IsModPinned(mod.UniqueId) is false;
        }

        /// <summary>
        /// Reassigns what every collection mod shows from the cached records without a rescan. DiscoverMods reads
        /// the records once per pass and an install rescans before its record is saved. Those passes can only
        /// give the mods it installed the source ID fallback and would read them all as the user's add-ons.
        /// </summary>
        internal void RefreshCollectionDetails()
        {
            var collectionsBySourceId = GetCollectionsBySourceId();
            foreach (var mod in Mods)
            {
                ApplyCollectionDetails(mod, collectionsBySourceId);
            }
        }

        /// <summary>
        /// The folders a discovery pass walks. Collections are installed outside the mod folder, so they are a root
        /// of their own rather than something the mod folder walk reaches on its way down.
        /// </summary>
        private static List<string> GetScanRoots(string modsFilePath)
        {
            var roots = new List<string>();
            if (String.IsNullOrEmpty(modsFilePath) is false && Directory.Exists(modsFilePath))
            {
                roots.Add(modsFilePath);
            }

            // Skipped when the mod folder already contains it, which would otherwise walk every collection twice
            var collectionsPath = Pathing.GetCollectionsFolderPath();
            if (Directory.Exists(collectionsPath) && roots.Any(r => Pathing.IsSameOrUnder(collectionsPath, r)) is false)
            {
                roots.Add(collectionsPath);
            }

            return roots;
        }

        /// <summary>
        /// Walks every root, keeping each file paired with the root it was found under. The root has to travel with
        /// the file because <see cref="ParentFolderContainsPeriod"/> measures from it, and the collections root sits
        /// under the application data folder, which is itself a dotted folder on Linux and macOS. Measuring a
        /// collection mod from the mod folder would find that period and hide every collection mod on those systems.
        /// </summary>
        private static List<(string Root, FileInfo File)> GetDiscoverableFiles(List<string> scanRoots, Func<DirectoryInfo, List<FileInfo>> walkRoot)
        {
            var found = new List<(string Root, FileInfo File)>();
            foreach (var root in scanRoots)
            {
                foreach (var file in walkRoot(new DirectoryInfo(root)))
                {
                    found.Add((root, file));
                }
            }

            return found;
        }

        /// <summary>
        /// The mod folder equivalent of <see cref="GetDiscoverableFiles"/>, carrying the root for the same reason.
        /// </summary>
        private List<(string Root, FileInfo Manifest, FileInfo? Config)> GetDiscoverableModFolders(List<string> scanRoots)
        {
            var found = new List<(string Root, FileInfo Manifest, FileInfo? Config)>();
            foreach (var root in scanRoots)
            {
                foreach (var (manifest, config) in GetModFolders(new DirectoryInfo(root)))
                {
                    found.Add((root, manifest, config));
                }
            }

            return found;
        }

        /// <summary>
        /// Finds every mod folder below the given directory, taking a folder that holds a manifest.json as a mod
        /// and not descending past it. The config.json is picked out of the same enumeration that finds the
        /// manifest, as walking for it separately reads every directory on disk a second time.
        /// </summary>
        public List<(FileInfo Manifest, FileInfo? Config)> GetModFolders(DirectoryInfo modDirectory)
        {
            List<(FileInfo Manifest, FileInfo? Config)> modFolders = new List<(FileInfo Manifest, FileInfo? Config)>();
            foreach (var directory in modDirectory.EnumerateDirectories())
            {
                try
                {
                    FileInfo? localManifest = null;
                    FileInfo? localConfig = null;
                    foreach (var file in directory.EnumerateFiles())
                    {
                        if (file.Name.Equals("manifest.json", StringComparison.OrdinalIgnoreCase))
                        {
                            localManifest = file;
                        }
                        else if (file.Name.Equals("config.json", StringComparison.OrdinalIgnoreCase))
                        {
                            localConfig = file;
                        }
                    }

                    if (localManifest is null)
                    {
                        modFolders.AddRange(GetModFolders(directory));
                    }
                    else
                    {
                        modFolders.Add((localManifest, localConfig));
                    }
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"There was an error when attempting to get the manifest.json within the directory ({(directory is null ? String.Empty : directory.FullName)}): {ex}", Helper.Status.Alert);
                }
            }

            return modFolders;
        }

        public bool HasModInstalled(string uniqueID)
        {
            return Mods.Any(m => m.UniqueId.Equals(uniqueID, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Only use to install new mods that don't currently exist within manager. Use MainWindow.AddMods for the safer method (update handling, various safety checks, etc.)
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public async Task<List<Mod>> DirectModInstallAsync(string? fileFullName)
        {
            List<Mod> addedMods = new List<Mod>();
            if (string.IsNullOrEmpty(fileFullName))
            {
                return addedMods;
            }

            try
            {
                // Extract the archive data
                using (var archive = ArchiveFactory.OpenArchive(fileFullName))
                {
                    Dictionary<string, Manifest?> pathToManifests = new Dictionary<string, Manifest?>();
                    foreach (var manifest in archive.Entries.Where(e => Path.GetFileName(e.Key)!.Equals("manifest.json", StringComparison.OrdinalIgnoreCase)))
                    {
                        if (manifest.Key is not null)
                        {
                            Program.helper.Log(manifest.Key);

                            // Skip any mods that already are installed (don't handle updates)
                            var parsedManifest = await ManifestParser.GetDataAsync(manifest);
                            if (parsedManifest is null || HasModInstalled(parsedManifest.UniqueID) is true)
                            {
                                continue;
                            }
                            pathToManifests[manifest.Key] = parsedManifest;
                        }
                    }

                    // Warn and skip the install logic if the given archive has no manifest.json
                    if (pathToManifests.Count == 0)
                    {
                        Program.helper.Log(String.Format(Program.translation.Get("ui.warning.no_manifest"), fileFullName));
                        return addedMods;
                    }

                    int currentManifestIndex = 1;
                    bool alwaysAskToDelete = Program.settings.AlwaysAskToDelete;
                    foreach (var manifestPath in pathToManifests.Keys)
                    {
                        var manifest = pathToManifests[manifestPath];

                        // If the archive doesn't have a manifest, warn the user
                        if (manifest is not null)
                        {
                            var installPath = Program.settings.ModInstallPath;
                            if (String.IsNullOrEmpty(manifestPath.Replace("manifest.json", String.Empty, StringComparison.OrdinalIgnoreCase)))
                            {
                                installPath = Path.Combine(installPath, manifest.UniqueID);
                            }

                            // Create the base directory, if needed
                            if (Directory.Exists(installPath) is false)
                            {
                                Directory.CreateDirectory(installPath);
                            }

                            Program.helper.Log($"Install path for mod {manifest.UniqueID}:{installPath}");
                            var manifestFolderPath = manifestPath.Replace("manifest.json", String.Empty, StringComparison.OrdinalIgnoreCase);
                            foreach (var entry in archive.Entries.Where(e => e.Key.StartsWith(manifestFolderPath)))
                            {
                                if (entry.Key.Contains("__MACOSX", StringComparison.OrdinalIgnoreCase) || entry.Key.Contains(".DS_Store", StringComparison.OrdinalIgnoreCase))
                                {
                                    continue;
                                }
                                var outputPath = Path.Combine(installPath, manifestFolderPath, String.IsNullOrEmpty(manifestFolderPath) ? entry.Key : Path.GetRelativePath(manifestFolderPath, entry.Key));

                                if (String.IsNullOrEmpty(manifestFolderPath) is false)
                                {
                                    var installDirectory = new DirectoryInfo(installPath);
                                    var manifestDirectory = new DirectoryInfo(manifestFolderPath);
                                    if (installDirectory.Exists && (installDirectory.Name.Equals(manifestDirectory.Name, StringComparison.OrdinalIgnoreCase) || installDirectory.Name.Equals(manifest.UniqueID)))
                                    {
                                        outputPath = Path.Combine(installPath, String.IsNullOrEmpty(manifestFolderPath) ? entry.Key : Path.GetRelativePath(manifestFolderPath, entry.Key));

                                        Program.helper.Log(outputPath);
                                    }
                                }
                                outputPath = Regex.Replace(outputPath, @"\s+\/", "/");

                                // Entry keys are whatever the packer wrote, so they can hold characters this file
                                // system rejects or a segment aiming above the install path. Rebuilding the path
                                // below installPath keeps both out, at the cost of a folder named slightly differently
                                var safeOutputPath = Pathing.GetSafeDestinationPath(installPath, Path.GetRelativePath(installPath, outputPath));
                                if (String.IsNullOrEmpty(safeOutputPath))
                                {
                                    Program.helper.Log($"Skipping {entry.Key}, as it does not resolve to a path inside {installPath}", Utilities.Helper.Status.Warning);
                                    continue;
                                }
                                outputPath = safeOutputPath;

                                // Create the default location if it doesn't existe
                                var outputFolder = Path.GetDirectoryName(outputPath);
                                if (String.IsNullOrEmpty(outputFolder))
                                {
                                    continue;
                                }
                                else if (Directory.Exists(outputFolder) is false)
                                {
                                    Directory.CreateDirectory(outputFolder);
                                }

                                if (entry.IsDirectory is false)
                                {
                                    Program.helper.Log($"Writing mod file to {outputPath}");
                                    await Task.Run(() => entry.WriteToFile(outputPath, new ExtractionOptions() { ExtractFullPath = false, Overwrite = true }));
                                }
                            }

                            // Built the same way the entries above were, so that it points at the folder they created
                            var modFolderPath = Pathing.GetSafeDestinationPath(installPath, manifestFolderPath) ?? installPath;
                            addedMods.Add(new Mod(manifest, new FileInfo(modFolderPath), manifest.UniqueID, manifest.Version, manifest.Name, manifest.Description, manifest.Author));
                        }
                        else
                        {
                            Program.helper.Log(String.Format(Program.translation.Get("ui.warning.no_manifest"), fileFullName));
                        }

                        currentManifestIndex += 1;
                    }
                }
            }
            catch (Exception ex)
            {
                Program.helper.Log($"Failed to unzip the file {fileFullName} due to the following error: {ex}", Utilities.Helper.Status.Warning);
            }

            return addedMods;
        }

        public void DiscoverMods(string modsFilePath)
        {
            var discoveredMods = new List<Mod>();
            var scanRoots = GetScanRoots(modsFilePath);
            if (scanRoots.Count == 0)
            {
                _mods.ReplaceAll(discoveredMods);
                HasCollectionMods = false;
                RefreshModCounts();
                return;
            }

            // Get cached key data
            List<ModKeyInfo> modKeysCache = new List<ModKeyInfo>();
            if (File.Exists(Pathing.GetKeyCachePath()))
            {
                try
                {
                    modKeysCache = JsonSerializer.Deserialize<List<ModKeyInfo>>(File.ReadAllText(Pathing.GetKeyCachePath()), new JsonSerializerOptions { AllowTrailingCommas = true });
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to parse cached mod keys: {ex}", Helper.Status.Alert);
                }
            }

            // Get the local data
            ClientData localDataCache = new ClientData();
            if (File.Exists(Pathing.GetDataCachePath()))
            {
                try
                {
                    localDataCache = JsonSerializer.Deserialize<ClientData>(File.ReadAllText(Pathing.GetDataCachePath()), new JsonSerializerOptions { AllowTrailingCommas = true });
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to parse client data: {ex}", Helper.Status.Alert);
                }
            }

            // Read once for the whole pass rather than once per mod, as every mod in a collection resolves to the
            // same record and CollectionCache.Load goes to disk each time it is called
            var collectionsBySourceId = GetCollectionsBySourceId();

            // Indexed once for the pass. The key cache holds thousands of entries and was previously scanned in
            // full for every dependency of every mod
            var modKeysByUniqueId = new Dictionary<string, ModKeyInfo>(StringComparer.OrdinalIgnoreCase);
            if (modKeysCache is not null)
            {
                foreach (var modKey in modKeysCache)
                {
                    if (modKey is null || String.IsNullOrEmpty(modKey.UniqueId))
                    {
                        continue;
                    }

                    modKeysByUniqueId.TryAdd(modKey.UniqueId, modKey);
                }
            }

            // ModReference is a record whose Equals and GetHashCode already compare the (UniqueId, SourceId) pair
            // case-insensitively, which is exactly what Matches does, so it serves as the key directly
            var installDataByReference = new Dictionary<ModReference, ModInstallData>();
            if (localDataCache is not null && localDataCache.ModInstallData is not null)
            {
                foreach (var installData in localDataCache.ModInstallData)
                {
                    if (installData is null || String.IsNullOrEmpty(installData.UniqueId))
                    {
                        continue;
                    }

                    installDataByReference.TryAdd(installData.ToReference(), installData);
                }
            }

            // Index the discovered mods by reference while scanning.
            var modIndexByReference = new Dictionary<ModReference, int>();

            ModKeyInfo? GetModKey(string? uniqueId)
            {
                if (String.IsNullOrEmpty(uniqueId))
                {
                    return null;
                }

                return modKeysByUniqueId.TryGetValue(uniqueId, out var modKey) ? modKey : null;
            }

            foreach (var (scanRoot, manifestInfo, configInfo) in GetDiscoverableModFolders(scanRoots))
            {
                if (manifestInfo.DirectoryName is null || (Program.settings.IgnoreHiddenFolders && ParentFolderContainsPeriod(scanRoot, manifestInfo.Directory)))
                {
                    continue;
                }

                try
                {
                    var manifest = ManifestParser.GetData(File.ReadAllText(manifestInfo.FullName));
                    if (manifest is null || String.IsNullOrEmpty(manifest.UniqueID))
                    {
                        Program.helper.Log($"The manifest.json was empty or not deserializable from {manifestInfo.DirectoryName}", Helper.Status.Alert);
                        continue;
                    }

                    var mod = new Mod(manifest, manifestInfo, manifest.UniqueID, manifest.Version, manifest.Name, manifest.Description, manifest.Author);
                    ApplyCollectionDetails(mod, collectionsBySourceId);

                    // Identity is (SourceId, UniqueId), so a collection's pinned copy never displaces a loose install of the same mod
                    var modReference = mod.ToReference();
                    if (manifest.ContentPackFor is not null)
                    {
                        var dependencyKey = GetModKey(manifest.ContentPackFor.UniqueID);
                        mod.FrameworkID = manifest.ContentPackFor.UniqueID;
                        mod.Requirements.Add(new ManifestDependency(manifest.ContentPackFor.UniqueID, manifest.ContentPackFor.MinimumVersion, true) { Name = dependencyKey is null ? manifest.ContentPackFor.UniqueID : dependencyKey.Name });
                    }
                    if (manifest.Dependencies is not null)
                    {
                        foreach (var dependency in manifest.Dependencies)
                        {
                            if (mod.Requirements.Any(r => r.UniqueID.Equals(dependency.UniqueID, StringComparison.OrdinalIgnoreCase)))
                            {
                                continue;
                            }

                            var dependencyKey = GetModKey(dependency.UniqueID);
                            mod.Requirements.Add(new ManifestDependency(dependency.UniqueID, dependency.MinimumVersion, dependency.IsRequired) { Name = dependencyKey is null ? dependency.UniqueID : dependencyKey.Name });
                        }
                    }

                    var modKey = GetModKey(mod.UniqueId);
                    if (modKey is not null)
                    {
                        mod.ModPageUri = modKey.PageUrl;
                    }

                    // Matched on the copy rather than the unique ID, so a collection's pinned mod and the user's own
                    // install of it keep their own dates. A record written before SourceId existed carries none, so
                    // it matches the loose copy and a collection copy simply starts fresh
                    if (installDataByReference.TryGetValue(modReference, out var installData))
                    {
                        mod.InstallTimestamp = installData.InstallTimestamp;
                        mod.LastUpdateTimestamp = installData.LastUpdateTimestamp;
                    }

                    if (localDataCache is not null && localDataCache.IgnoredUpdates is not null && localDataCache.IgnoredUpdates.TryGetValue(mod.UniqueId, out string? value))
                    {
                        mod.IgnoredVersion = value;
                    }

                    // Taken from the walk that found the manifest, rather than a second pass over the tree
                    if (configInfo is not null)
                    {
                        mod.Config = new Config() { UniqueId = mod.UniqueId, FilePath = configInfo.FullName, LastWriteTimeUtc = configInfo.LastWriteTimeUtc, Data = File.ReadAllText(configInfo.FullName) };
                    }

                    // Add or update the mod
                    if (modIndexByReference.TryGetValue(modReference, out var existingIndex) is false)
                    {
                        modIndexByReference[modReference] = discoveredMods.Count;
                        discoveredMods.Add(mod);
                    }
                    else if (discoveredMods[existingIndex].Version.CompareSortOrderTo(mod.Version) < 0)
                    {
                        // Replace old mod with newer one
                        discoveredMods[existingIndex] = mod;
                    }
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Unable to load the manifest.json from {manifestInfo.DirectoryName}: {ex}", Helper.Status.Alert);
                }
            }

            // Update the local data before publishing the scan in one collection reset.
            var modInstallData = new List<ModInstallData>();
            foreach (var mod in discoveredMods)
            {
                if (mod.InstallTimestamp is null)
                {
                    mod.InstallTimestamp = DateTime.Now;
                }

                modInstallData.Add(new ModInstallData() { UniqueId = mod.UniqueId, SourceId = mod.SourceId, InstallTimestamp = mod.InstallTimestamp.Value, LastUpdateTimestamp = mod.LastUpdateTimestamp });
            }
            localDataCache.ModInstallData = modInstallData;

            // Cache the local data
            File.WriteAllText(Pathing.GetDataCachePath(), JsonSerializer.Serialize(localDataCache, new JsonSerializerOptions() { WriteIndented = true }));

            using (DataView?.DeferRefresh())
            {
                _mods.ReplaceAll(discoveredMods);
                EvaluateRequirements();
                HideRequiredMods();
                HasCollectionMods = Mods.Any(m => m.IsFromCollection);
            }

            if (Program.settings.ShowModThumbnails)
            {
                UpdateThumbnails();
            }
        }

        public void HideRequiredMods()
        {
            var requiredModIds = new List<string> { "SMAPI.ConsoleCommands", "SMAPI.ErrorHandler", "SMAPI.SaveBackup" };
            foreach (var mod in Mods.Where(m => requiredModIds.Any(id => id.Equals(m.UniqueId, StringComparison.OrdinalIgnoreCase))))
            {
                mod.IsHidden = true;
                mod.IsEnabled = true;
            }

            RefreshModCounts();

            // Update data grid grouping
            UpdateDataGridGrouping();
        }

        /// <summary>
        /// Finds the copy of a dependency that will actually be loaded alongside the given mod. With collections in
        /// play the same unique ID can exist several times, so a copy that is already enabled is taken before any
        /// other, and a mod's dependency otherwise resolves within its own source first. Falling back to any copy
        /// would mark a requirement satisfied by a mod that is not enabled.
        /// </summary>
        internal Mod? ResolveRequirement(Mod dependent, string requirementUniqueId)
        {
            return ResolveRequirement(dependent,
                Mods.Where(mod => mod.UniqueId.Equals(requirementUniqueId, StringComparison.OrdinalIgnoreCase)).ToList());
        }

        private static Mod? ResolveRequirement(Mod dependent, IEnumerable<Mod> candidates)
        {

            // An enabled copy wins over everything else, the dependent's own source first. Each enabled mod is
            // handed to SMAPI as a junction of its own, so resolving past one that is already on and enabling a
            // second copy puts two folders claiming the same unique ID in the mods folder
            var enabledMatch = candidates.FirstOrDefault(m => m.IsEnabled && String.Equals(m.SourceId, dependent.SourceId, StringComparison.OrdinalIgnoreCase));
            if (enabledMatch is null)
            {
                enabledMatch = candidates.FirstOrDefault(m => m.IsEnabled);
            }

            if (enabledMatch is not null)
            {
                return enabledMatch;
            }

            // Nothing is on yet, so the copy that belongs alongside the dependent is the one to reach for
            var sameSourceMatch = candidates.FirstOrDefault(m => String.Equals(m.SourceId, dependent.SourceId, StringComparison.OrdinalIgnoreCase));
            if (sameSourceMatch is not null)
            {
                return sameSourceMatch;
            }

            // A collection mod can legitimately depend on something the user already had loose, so a loose install
            // is a valid fallback even while off. The reverse only holds through the enabled check above, as a
            // loose mod has no claim on a collection's copy unless that copy is already going to load
            if (dependent.IsFromCollection)
            {
                return candidates.FirstOrDefault(m => m.IsFromCollection is false);
            }

            return null;
        }

        /// <summary>
        /// The mods that would actually load the given mod as a requirement. The mirror of
        /// <see cref="ResolveRequirement"/>: a mod naming this unique ID only counts as a dependent when this is
        /// the copy its own source resolves to, so acting on a collection's copy leaves an identically named loose
        /// copy and everything depending on that one alone.
        /// </summary>
        internal List<Mod> GetDependents(Mod mod)
        {
            var dependents = new List<Mod>();
            foreach (var candidate in Mods.Where(m => m.Requirements.Any(r => r.IsRequired && r.UniqueID.Equals(mod.UniqueId, StringComparison.OrdinalIgnoreCase))))
            {
                if (ReferenceEquals(ResolveRequirement(candidate, mod.UniqueId), mod))
                {
                    dependents.Add(candidate);
                }
            }

            return dependents;
        }

        public void EvaluateRequirements()
        {
            var keysById = new Dictionary<string, ModKeyInfo>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (File.Exists(Pathing.GetKeyCachePath()))
                {
                    var keys = JsonSerializer.Deserialize<List<ModKeyInfo>>(File.ReadAllText(Pathing.GetKeyCachePath()),
                        new JsonSerializerOptions { AllowTrailingCommas = true });
                    foreach (var key in keys ?? Enumerable.Empty<ModKeyInfo>())
                    {
                        if (!String.IsNullOrEmpty(key?.UniqueId))
                        {
                            keysById.TryAdd(key.UniqueId, key);
                        }
                    }
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException)
            {
                Program.helper.Log($"Unable to read the cached mod names: {ex.Message}", Helper.Status.Warning);
            }
            var modsById = Mods.ToLookup(mod => mod.UniqueId, StringComparer.OrdinalIgnoreCase);

            // Flag any missing requirements
            foreach (var mod in Mods)
            {
                try
                {
                    foreach (var requirement in mod.Requirements.Where(r => r.IsRequired))
                    {
                        var matchedMod = ResolveRequirement(mod, modsById[requirement.UniqueID]);
                        if (matchedMod is null || matchedMod.IsModOutdated(requirement.MinimumVersion))
                        {
                            requirement.IsMissing = true;

                            requirement.Name = keysById.TryGetValue(requirement.UniqueID, out var key)
                                ? key.Name : requirement.UniqueID;
                        }
                        else
                        {
                            // Clear the flag, otherwise a requirement stays missing after it has been satisfied on
                            // any pass that does not rebuild the mod list first
                            requirement.IsMissing = false;
                        }
                    }

                    mod.NotifyPropertyChanged("Requirements");
                    mod.NotifyPropertyChanged("MissingRequirements");
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to check requirements for {mod.Name} due to the following error: {ex}");
                }
            }
        }

        public List<FileInfo> GetConfigFiles(DirectoryInfo modDirectory)
        {
            List<FileInfo> configs = new List<FileInfo>();
            foreach (var directory in modDirectory.EnumerateDirectories())
            {
                var localConfigs = directory.EnumerateFiles("config.json");
                if (localConfigs.Count() == 0)
                {
                    configs.AddRange(GetConfigFiles(directory));
                    continue;
                }

                var localConfig = localConfigs.First();
                if (localConfig.Directory is not null && localConfig.Directory.EnumerateFiles("manifest.json", SearchOption.TopDirectoryOnly).Count() == 1)
                {
                    configs.Add(localConfig);
                }
            }

            return configs;
        }

        public void DiscoverConfigs(string modsFilePath, bool useArchive = false)
        {
            var modsByDirectory = new Dictionary<string, Mod>(StringComparer.Ordinal);
            foreach (var knownMod in Mods)
            {
                if (knownMod.ModFileInfo is null || knownMod.ModFileInfo.DirectoryName is null)
                {
                    continue;
                }

                modsByDirectory.TryAdd(knownMod.ModFileInfo.DirectoryName, knownMod);
            }

            foreach (var (scanRoot, fileInfo) in GetDiscoverableFiles(GetScanRoots(modsFilePath), GetConfigFiles))
            {
                if (fileInfo.DirectoryName is null || (Program.settings.IgnoreHiddenFolders && ParentFolderContainsPeriod(scanRoot, fileInfo.Directory)))
                {
                    continue;
                }

                if (modsByDirectory.TryGetValue(fileInfo.DirectoryName, out var mod) is false)
                {
                    continue;
                }
                else if (useArchive && mod.Config is not null)
                {
                    if (fileInfo.LastWriteTimeUtc <= mod.Config.LastWriteTimeUtc)
                    {
                        continue;
                    }

                    mod.Config.Data = File.ReadAllText(fileInfo.FullName);
                    mod.Config.LastWriteTimeUtc = fileInfo.LastWriteTimeUtc;
                }
                else
                {
                    mod.Config = new Config() { UniqueId = mod.UniqueId, FilePath = fileInfo.FullName, LastWriteTimeUtc = fileInfo.LastWriteTimeUtc, Data = File.ReadAllText(fileInfo.FullName) };
                }
            }
        }

        internal List<Config> GetPendingConfigUpdates(Profile profile, bool excludeMissingConfigs = false, bool useArchiveAsBase = false)
        {
            // Merge any existing preserved configs
            List<Config> pendingConfigUpdates = new List<Config>();
            foreach (var reference in profile.EnabledModIds)
            {
                var modId = reference.UniqueId.ToLower();
                var mod = Mods.FirstOrDefault(m => reference.Matches(m));
                if (mod is null || mod.ModFileInfo is null)
                {
                    continue;
                }

                // A collection owns the configuration of the mods it installs, the same way it owns their versions.
                // Its curator ships configuration as part of the curated result, and preserving a snapshot of that
                // would merge it back over whatever they publish next. The file in the collection's folder is the
                // configuration, with nothing shadowing it
                if (mod.IsFromCollection)
                {
                    continue;
                }

                try
                {
                    if (profile.PreservedModConfigs.ContainsKey(modId))
                    {
                        // Write the archived config, if the current one doesn't exist
                        if (mod.Config is null)
                        {
                            if (excludeMissingConfigs || String.IsNullOrEmpty(mod.ModFileInfo.DirectoryName))
                            {
                                continue;
                            }

                            mod.Config = new Config() { UniqueId = modId, FilePath = Path.Combine(mod.ModFileInfo.DirectoryName, "config.json"), Data = JsonTools.ParseDocumentToString(profile.PreservedModConfigs[modId]) };
                            pendingConfigUpdates.Add(mod.Config);
                        }
                        else
                        {
                            // Merge the config
                            var currentJson = mod.Config.Data;
                            var archivedJson = JsonTools.ParseDocumentToString(profile.PreservedModConfigs[modId]);
                            if (JsonDocumentEqualityComparer.Instance.Equals(JsonDocument.Parse(mod.Config.Data), profile.PreservedModConfigs[modId]) is false)
                            {
                                // JsonTools.Merge will preserve the originalJson values, but will add new properties from archivedJson
                                string mergedJson = String.Empty;
                                if (useArchiveAsBase is false)
                                {
                                    mergedJson = JsonTools.Merge(archivedJson, currentJson, false); ;
                                }
                                else
                                {
                                    mergedJson = JsonTools.Merge(currentJson, archivedJson, false);
                                }

                                // Apply the changes to the config file
                                //Program.helper.Log($"The mod {modId} does not have its current configuration preserved\nCurrent:\n{currentJson}\nArchived:\n{archivedJson}", Helper.Status.Warning);
                                pendingConfigUpdates.Add(new Config() { UniqueId = modId, FilePath = mod.Config.FilePath, Data = mergedJson });
                            }
                        }
                    }
                    else if (mod.Config is not null)
                    {
                        pendingConfigUpdates.Add(new Config() { UniqueId = modId, FilePath = mod.Config.FilePath, Data = mod.Config.Data });
                    }
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to process config.json for mod {modId}: {ex}", Helper.Status.Warning);
                }
            }

            return pendingConfigUpdates;
        }

        internal async void UpdateEndorsements()
        {
            if (Nexus.Client is null)
            {
                return;
            }

            var endorsements = await Nexus.Client.GetEndorsements();
            foreach (var mod in Mods.Where(m => m.HasUpdateKeys() && endorsements.Any(e => e.Id == m.NexusModId)))
            {
                mod.IsEndorsed = endorsements.First(e => e.Id == mod.NexusModId).IsEndorsed();
            }
        }

        private int _thumbnailRefreshVersion;
        private readonly Dictionary<int, Task<string?>> _thumbnailDownloads = new Dictionary<int, Task<string?>>();

        internal async void UpdateThumbnails()
        {
            var version = ++_thumbnailRefreshVersion;
            var modsByNexusId = Mods.Select(mod => (Mod: mod, Id: mod.NexusModId))
                .Where(item => item.Id.HasValue)
                .ToLookup(item => item.Id!.Value, item => item.Mod);
            try
            {
                var directory = Pathing.GetThumbnailsPath();
                var cached = await Task.Run(() => Directory.Exists(directory)
                    ? Directory.EnumerateFiles(directory).ToLookup(Path.GetFileNameWithoutExtension, StringComparer.OrdinalIgnoreCase)
                    : Enumerable.Empty<string>().ToLookup(Path.GetFileNameWithoutExtension, StringComparer.OrdinalIgnoreCase));

                // Yield between batches so opening the window and scrolling take priority over decoding images.
                foreach (var batch in modsByNexusId.Chunk(24))
                {
                    await Dispatcher.UIThread.InvokeAsync(() =>
                    {
                        if (version != _thumbnailRefreshVersion || !Program.settings.ShowModThumbnails)
                        {
                            return;
                        }
                        foreach (var mods in batch)
                        {
                            var path = cached[mods.Key.ToString()].FirstOrDefault();
                            if (path is not null)
                            {
                                foreach (var mod in mods)
                                {
                                    mod.NexusModThumbnailPath = path;
                                }
                            }
                        }
                    }, DispatcherPriority.Background);
                    if (version != _thumbnailRefreshVersion || !Program.settings.ShowModThumbnails)
                    {
                        return;
                    }
                }

                foreach (var mods in modsByNexusId)
                {
                    var client = Nexus.Client;
                    if (version != _thumbnailRefreshVersion || !Program.settings.ShowModThumbnails || client is null)
                    {
                        return;
                    }
                    if (cached.Contains(mods.Key.ToString()) || mods.All(mod => mod.NexusModThumbnailPath is not null))
                    {
                        continue;
                    }
                    if (!_thumbnailDownloads.TryGetValue(mods.Key, out var download))
                    {
                        download = client.DownloadThumbnail(mods.Key);
                        _thumbnailDownloads.Add(mods.Key, download);
                    }
                    var path = await download;
                    if (version != _thumbnailRefreshVersion || !Program.settings.ShowModThumbnails)
                    {
                        return;
                    }
                    if (path is not null)
                    {
                        foreach (var mod in mods)
                        {
                            mod.NexusModThumbnailPath = path;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Program.helper.Log($"Could not refresh mod thumbnails: {ex}", Helper.Status.Warning);
            }
        }

        /// <summary>
        /// Whether the profile enables mods whose configuration belongs to a collection. Lets an empty save be told
        /// apart from one that found no configuration at all, since these mods are visibly carrying configuration in
        /// the grid and their absence from a save needs explaining.
        /// </summary>
        internal bool HasCollectionOwnedConfigs(Profile profile)
        {
            foreach (var reference in profile.EnabledModIds)
            {
                var mod = Mods.FirstOrDefault(m => reference.Matches(m));
                if (mod is null || mod.IsFromCollection is false)
                {
                    continue;
                }

                if (mod.HasConfig)
                {
                    return true;
                }
            }

            return false;
        }

        internal void ReadModConfigs(Profile profile)
        {
            ReadModConfigs(profile, GetPendingConfigUpdates(profile));
        }

        internal void ReadModConfigs(Profile profile, List<Config> pendingConfigUpdates)
        {
            foreach (var configInfo in pendingConfigUpdates)
            {
                try
                {
                    profile.PreservedModConfigs[configInfo.UniqueId] = JsonDocument.Parse(configInfo.Data);
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to read config for the mod {configInfo.UniqueId} due to the following error:\n{ex}");
                }
            }
        }

        internal bool WriteModConfigs(Profile profile)
        {
            return WriteModConfigs(profile, GetPendingConfigUpdates(profile, useArchiveAsBase: true));
        }

        internal bool WriteModConfigs(Profile profile, List<Config> pendingConfigUpdates)
        {
            if (pendingConfigUpdates.Count == 0)
            {
                return false;
            }

            // Merge any existing preserved configs
            foreach (var configInfo in pendingConfigUpdates.Where(c => profile.PreservedModConfigs.ContainsKey(c.UniqueId.ToLower())))
            {
                try
                {
                    var fileInfo = new FileInfo(configInfo.FilePath);
                    if (!Directory.Exists(fileInfo.DirectoryName))
                    {
                        continue;
                    }

                    // Apply the changes to the config file
                    File.WriteAllText(configInfo.FilePath, configInfo.Data);
                }
                catch (Exception ex)
                {
                    Program.helper.Log($"Failed to write config for the mod {configInfo.UniqueId} due to the following error:\n{ex}");
                }
            }

            return true;
        }

        public void EnableModsByProfile(Profile profile)
        {
            // Cached so the source filter does not walk the reference list once per grid row
            _activeProfile = profile;
            _activeProfileReferences = new HashSet<ModReference>(profile.EnabledModIds);

            foreach (var mod in Mods)
            {
                mod.IsEnabled = _activeProfileReferences.Contains(mod.ToReference());
                mod.Note = SharedModNotes.Get(mod.UniqueId);
            }

            using (DataView.DeferRefresh())
            {
                HideRequiredMods();
                UpdateFilter();
            }
        }

        /// <summary>
        /// Whether the source scoping is set aside for the moment. Asking to see updatable mods is a request for the
        /// mods that have updates, wherever they live. Left in place, a collection profile answers it with an empty
        /// grid while the count beside the button reports several waiting, as collection mods never carry update
        /// data and the profile shows nothing else.
        /// </summary>
        private bool IsSourceFilterOverridden()
        {
            return _showUpdatableMods;
        }

        /// <summary>
        /// Whether a mod belongs to what the user is currently looking at. A collection profile shows everything the
        /// collection installed, plus anything it reuses from outside its own folder. A plain profile shows
        /// everything no collection owns, plus any collection mod it enables.
        /// </summary>
        private bool PassesSourceFilter(Mod mod)
        {
            if (_modSourceFilter is ModSourceFilter.All || IsSourceFilterOverridden())
            {
                return true;
            }

            if (_activeProfile is not null && _activeProfile.IsFromCollection)
            {
                // A mod this collection installed belongs on screen whether or not it is currently enabled, as the
                // collection is what defines the profile's contents. Answered from SourceId, which comes off the
                // folder path and so outlives the profile being saved without the mod in it. Reading membership from
                // the references alone made disabling a mod remove it from the view at the next profile pass
                if (String.Equals(mod.SourceId, _activeProfile.SourceId, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                // Anything else is on screen because the profile reaches outside the collection for it, which is not
                // recorded anywhere but the references
                return _activeProfileReferences.Contains(mod.ToReference());
            }

            if (mod.IsFromCollection is false)
            {
                return true;
            }

            // A collection mod is on screen in a plain profile only because the profile enables it, such as in a copy
            // of a collection's profile. Hiding those left the profile running mods the grid never showed
            return _activeProfileReferences.Contains(mod.ToReference());
        }

        /// <summary>
        /// Recalculates the footer counts. These follow the source filter, otherwise the totals disagree with what
        /// the grid is showing. That includes the override above, so turning on Show Updatable Mods widens the
        /// counts alongside the grid rather than leaving them describing a scope the grid has stepped out of.
        /// </summary>
        public void RefreshModCounts()
        {
            EnabledModCount = Mods.Count(m => m.IsEnabled && m.IsHidden is false && PassesSourceFilter(m));
            ActualModCount = Mods.Count(m => m.IsHidden is false && PassesSourceFilter(m));
        }

        public void ForceModState(Profile profile, List<Mod> mods, bool modEnableState = false)
        {
            foreach (var mod in Mods)
            {
                if (mods.Any(m => m.UniqueId.Equals(mod.UniqueId, StringComparison.OrdinalIgnoreCase)) is false)
                {
                    continue;
                }
                mod.IsEnabled = modEnableState;
            }

            // Matched on the unique ID alone, so a mod a collection and the mod folder both provide has just had
            // every copy turned on
            if (modEnableState)
            {
                ResolveEnabledDuplicates();
            }

            RefreshModCounts();
        }

        /// <summary>
        /// Turns off every other enabled copy of the given mods' unique IDs. Each enabled mod is handed to SMAPI as
        /// a junction of its own, so two folders claiming one unique ID is an error rather than a preference, and
        /// the copy the user acted on is the one that stands.
        /// </summary>
        internal void DisableDuplicatesOf(IEnumerable<Mod> mods)
        {
            foreach (var mod in mods.Where(m => m.IsEnabled).ToList())
            {
                foreach (var duplicate in Mods.Where(m => m.IsEnabled && ReferenceEquals(m, mod) is false && m.UniqueId.Equals(mod.UniqueId, StringComparison.OrdinalIgnoreCase)).ToList())
                {
                    Program.helper.Log($"Disabling {duplicate.Name} ({duplicate.SourceId ?? "local"}), as another copy of {duplicate.UniqueId} has been enabled");
                    duplicate.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Collapses every unique ID down to one enabled copy. Used by the paths that turn mods on in bulk, where
        /// there is no single mod the user acted on to keep, so the copy belonging to the active profile wins,
        /// then a loose install, then whichever was found first.
        /// </summary>
        internal void ResolveEnabledDuplicates()
        {
            var preferredSourceId = _activeProfile is not null && _activeProfile.IsFromCollection ? _activeProfile.SourceId : null;
            foreach (var group in Mods.Where(m => m.IsEnabled).GroupBy(m => m.UniqueId, StringComparer.OrdinalIgnoreCase).ToList())
            {
                var copies = group.ToList();
                if (copies.Count < 2)
                {
                    continue;
                }

                var keptCopy = copies.FirstOrDefault(m => String.Equals(m.SourceId, preferredSourceId, StringComparison.OrdinalIgnoreCase));
                if (keptCopy is null)
                {
                    keptCopy = copies.FirstOrDefault(m => m.IsFromCollection is false);
                }

                if (keptCopy is null)
                {
                    keptCopy = copies.First();
                }

                DisableDuplicatesOf(new List<Mod> { keptCopy });
            }
        }

        /// <summary>
        /// Re-reads every mod custom category from the store and rebuilds the grid groups. Used after a
        /// category is created or deleted, where more than the clicked mod can be affected.
        /// </summary>
        internal void ReapplyCustomCategories()
        {
            var uncategorized = Program.translation.Get("ui.main_window.menu_items.context.custom_category_none");
            foreach (var mod in Mods)
            {
                var category = Program.customCategories.Get(mod.UniqueId);
                mod.CustomCategory = String.IsNullOrEmpty(category) ? uncategorized : category;
            }

            RefreshCustomGrouping();
        }

        /// <summary>
        /// Rebuilds the grid groups after a mod custom category changed, so it moves to its new group
        /// without a full mod rescan.
        /// </summary>
        internal void RefreshCustomGrouping()
        {
            if (Program.settings.ModGroupingMethod == ModGrouping.Custom)
            {
                if (DataView is not null)
                {
                    using (DataView.DeferRefresh())
                    {
                        UpdateDataGridGrouping();
                        ResetGridFilter();
                    }
                }
            }
        }

        private static DataGridPathGroupDescription GroupDirectModsFirst(string propertyName)
        {
            var grouping = new DataGridPathGroupDescription(propertyName);
            // Avalonia puts explicit group keys ahead of groups discovered from the sorted mods.
            grouping.GroupKeys.Add(Mod.DirectCategoryGroup);
            return grouping;
        }

        internal void UpdateDataGridGrouping()
        {
            if (DataView is not null)
            {
                var desiredGroupings = new List<DataGridPathGroupDescription>();
                switch (Program.settings.ModGroupingMethod)
                {
                    case ModGrouping.Folder:
                        desiredGroupings.Add(_modPathGrouping);
                        break;
                    case ModGrouping.FolderCondensed:
                        desiredGroupings.Add(_rootPathGrouping);
                        break;
                    case ModGrouping.ContentPack:
                        desiredGroupings.Add(_frameworkGrouping);
                        break;
                    case ModGrouping.Custom:
                        desiredGroupings.Add(_customCategoryRootGrouping);
                        desiredGroupings.Add(_customCategorySubGrouping);
                        if (Mods.Any(mod => mod.HasThirdCustomCategoryLevel))
                        {
                            desiredGroupings.Add(_customCategoryThirdGrouping);
                        }
                        break;
                }

                foreach (var grouping in DataView.GroupDescriptions.OfType<DataGridPathGroupDescription>().ToList())
                {
                    if (desiredGroupings.Contains(grouping) is false)
                    {
                        DataView.GroupDescriptions.Remove(grouping);
                    }
                }

                foreach (var grouping in desiredGroupings)
                {
                    if (DataView.GroupDescriptions.Contains(grouping) is false)
                    {
                        DataView.GroupDescriptions.Add(grouping);
                    }
                }

                HandleModGroupingSorting();
            }
        }


        /// <summary>
        /// The mods the grid is showing. Bulk actions run through this so that what the user is looking at is what
        /// they act on, which takes in the source filter, the search box, the enabled and disabled filters and the
        /// hidden mods under one rule. Evaluated against the current state rather than read back off DataView, so a
        /// mod toggled since the last filter pass is judged on where it stands now.
        /// </summary>
        public List<Mod> GetVisibleMods()
        {
            return Mods.Where(m => ModFilter(m)).ToList();
        }

        internal void UpdateFilter()
        {
            if (DataView is not null)
            {
                TrackEnabledModsForSourceFilter();
                using (DataView.DeferRefresh())
                {
                    UpdateDataGridGrouping();
                    ResetGridFilter();
                }
            }
        }

        private void ResetGridFilter()
        {
            // Changing the predicate schedules one refresh when the enclosing DeferRefresh ends.
            DataView.Filter = null;
            DataView.Filter = ModFilter;
        }

        /// <summary>
        /// Folds whatever is currently enabled into the set the source filter shows. Done here rather than at each
        /// place a mod is toggled, as this runs immediately before the filter is applied and so catches every path
        /// that could have changed the enabled state. The set only grows within a session and is rebuilt from the
        /// profile whenever one is applied, which is what keeps a mod the profile reached outside the collection for
        /// on screen after the user disables it. A plain profile uses it the same way for the collection mods it
        /// enables. A mod the active collection installed no longer relies on this, as
        /// <see cref="PassesSourceFilter"/> answers for those from SourceId.
        /// </summary>
        private void TrackEnabledModsForSourceFilter()
        {
            if (_activeProfile is null)
            {
                return;
            }

            foreach (var mod in Mods.Where(m => m.IsEnabled))
            {
                _activeProfileReferences.Add(mod.ToReference());
            }
        }

        private bool ModFilter(object item)
        {
            var mod = item as Mod;
            if (mod is null)
            {
                return false;
            }

            if (mod.IsHidden)
            {
                return false;
            }

            if (PassesSourceFilter(mod) is false)
            {
                return false;
            }

            if (_disabledModFilter == DisplayFilter.ShowEnabled && !mod.IsEnabled)
            {
                return false;
            }
            else if (_disabledModFilter == DisplayFilter.ShowDisabled && mod.IsEnabled)
            {
                return false;
            }
            else if (_disabledModFilter == DisplayFilter.RequireConfig && !mod.HasConfig)
            {
                return false;
            }

            if (_showUpdatableMods && mod.HasActionableStatus is false)
            {
                return false;
            }

            if (String.IsNullOrEmpty(_filterText) || _columnFilter is null || !_columnFilter.Any())
            {
                return true;
            }

            if (!String.IsNullOrEmpty(_filterText) && _columnFilter.Any())
            {
                var filterTextNoWhitespace = _filterText.Replace(" ", String.Empty);
                if (_columnFilter.Contains(Program.translation.Get("ui.main_window.combobox.mod_name")) && mod.Name.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
                if (_columnFilter.Contains(Program.translation.Get("ui.main_window.combobox.group")))
                {
                    ModGrouping modGroupingMethod = Program.settings.ModGroupingMethod;
                    switch (Program.settings.ModGroupingMethod)
                    {
                        case ModGrouping.Folder:
                            if (mod.Path.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase) is true)
                            {
                                return true;
                            }
                            break;
                        case ModGrouping.FolderCondensed:
                            if (mod.RootPath.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase) is true)
                            {
                                return true;
                            }
                            break;
                        case ModGrouping.ContentPack:
                            if (mod.FrameworkID is not null && mod.FrameworkID.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase) is true)
                            {
                                return true;
                            }
                            break;
                    }
                }
                if (_columnFilter.Contains(Program.translation.Get("ui.main_window.combobox.top_level_group")))
                {
                    ModGrouping modGroupingMethod = Program.settings.ModGroupingMethod;
                    switch (Program.settings.ModGroupingMethod)
                    {
                        case ModGrouping.Folder:
                        case ModGrouping.FolderCondensed:
                            if (mod.RootPath is not null && mod.RootPath.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase) is true)
                            {
                                return true;
                            }
                            break;
                        case ModGrouping.ContentPack:
                            if (mod.FrameworkID is not null && mod.FrameworkID.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase) is true)
                            {
                                return true;
                            }
                            break;
                    }
                }
                if (_columnFilter.Contains(Program.translation.Get("ui.main_window.combobox.author")) && mod.Author.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
                if (_columnFilter.Contains(Program.translation.Get("ui.main_window.combobox.requirements")) && ((mod.HardRequirements is not null && mod.HardRequirements.Any(r => r.Name is null || r.Name.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase))) || (mod.MissingRequirements is not null && mod.MissingRequirements.Any(r => r.Name is null || r.Name.Replace(" ", String.Empty).Contains(filterTextNoWhitespace, StringComparison.OrdinalIgnoreCase)))))
                {
                    return true;
                }
            }

            return false;
        }

        private void DataViewSortDescription_CollectionChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            HandleModGroupingSorting();
        }

        private void HandleModGroupingSorting()
        {
            switch (Program.settings.ModGroupingMethod)
            {
                case ModGrouping.None:
                    break;
                case ModGrouping.Folder:
                    if (DataView.SortDescriptions.Any(d => d.PropertyPath == nameof(Mod.Path)) is false)
                    {
                        DataView.SortDescriptions.Add(DataGridSortDescription.FromPath(nameof(Mod.Path), ListSortDirection.Ascending));
                    }
                    break;
                case ModGrouping.FolderCondensed:
                    if (DataView.SortDescriptions.Any(d => d.PropertyPath == nameof(Mod.RootPath)) is false)
                    {
                        DataView.SortDescriptions.Add(DataGridSortDescription.FromPath(nameof(Mod.RootPath), ListSortDirection.Ascending));
                    }
                    break;
                case ModGrouping.ContentPack:
                    if (DataView.SortDescriptions.Any(d => d.PropertyPath == nameof(Mod.FrameworkID)) is false)
                    {
                        DataView.SortDescriptions.Add(DataGridSortDescription.FromPath(nameof(Mod.FrameworkID), ListSortDirection.Ascending));
                    }
                    break;
            }
        }
    }
}
